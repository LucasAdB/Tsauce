/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.telas;

import br.senac.conexaoBD.Conexao;
import com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

/**
 *
 * @author henrique.medeiros
 */
public class frm_buscar extends javax.swing.JFrame {

    Connection conexao = null;
    PreparedStatement ps = null; //Prepara a consulta de acordo com o comando sql(parametro) que for fornecido;
    ResultSet rs = null;

    public frm_buscar() {
        initComponents();
        conexao = Conexao.Conector();
    }
    frm_Contatos carregaSelecionado = new frm_Contatos();

    private void pesquisar_usuario() {
        String sql = "SELECT * FROM contatos where nome_contato like ?";
        try {
            ps = conexao.prepareStatement(sql);
            ps.setString(1, txtBuscar.getText() + "%");
            rs = ps.executeQuery();
            tbLista.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public void carregaDadosTabelaPesquisarContato() {
        String sql = "select * from contatos";
        try {
            ps = conexao.prepareStatement(sql);
            rs = ps.executeQuery();
            tbLista.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void selecionaDadoFiltrado() {
        int index = tbLista.getSelectedRow();
        TableModel model = tbLista.getModel();
        String id = model.getValueAt(index, 0).toString();
        String nome = model.getValueAt(index, 1).toString();
        String telefone = model.getValueAt(index, 2).toString();
        String email = model.getValueAt(index, 3).toString();
        String sexo = model.getValueAt(index, 4).toString();
        String endereco = model.getValueAt(index, 5).toString();
        String bairro = model.getValueAt(index, 6).toString();
        String cidade = model.getValueAt(index, 7).toString();
        String cep = model.getValueAt(index, 8).toString();
        String uf = model.getValueAt(index, 9).toString();

        carregaSelecionado.setVisible(true);
        carregaSelecionado.pack();
        carregaSelecionado.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        carregaSelecionado.txtID.setText(id);
        carregaSelecionado.txtNome.setText(nome);
        carregaSelecionado.txtTelefone.setText(telefone);
        carregaSelecionado.txtEmail.setText(email);
        switch (sexo) {
            case "Masculino":
                carregaSelecionado.cbSexo.setSelectedIndex(0);
                break;
            case "Feminino":
                carregaSelecionado.cbSexo.setSelectedIndex(1);
                break;
            default:
                carregaSelecionado.cbSexo.setSelectedIndex(-1);
                break;
        }
        carregaSelecionado.txtEndereco.setText(endereco);
        carregaSelecionado.txtBairro.setText(bairro);
        carregaSelecionado.txtCidade.setText(cidade);
        carregaSelecionado.txtCep.setText(cep);
        switch (uf) {
            case "AC":
                carregaSelecionado.cbUF.setSelectedIndex(0);
                break;
            case "AL":
                carregaSelecionado.cbUF.setSelectedIndex(1);
                break;
            case "AP":
                carregaSelecionado.cbUF.setSelectedIndex(2);
                break;
            case "AM":
                carregaSelecionado.cbUF.setSelectedIndex(3);
                break;
            case "BA":
                carregaSelecionado.cbUF.setSelectedIndex(4);
                break;
            case "CE":
                carregaSelecionado.cbUF.setSelectedIndex(5);
                break;
            case "DF":
                carregaSelecionado.cbUF.setSelectedIndex(6);
                break;
            case "ES":
                carregaSelecionado.cbUF.setSelectedIndex(7);
                break;
            case "GO":
                carregaSelecionado.cbUF.setSelectedIndex(8);
                break;
            case "MA":
                carregaSelecionado.cbUF.setSelectedIndex(9);
                break;
            case "MT":
                carregaSelecionado.cbUF.setSelectedIndex(10);
                break;
            case "MS":
                carregaSelecionado.cbUF.setSelectedIndex(11);
                break;
            case "MG":
                carregaSelecionado.cbUF.setSelectedIndex(12);
                break;
            case "PA":
                carregaSelecionado.cbUF.setSelectedIndex(13);
                break;
            case "PB":
                carregaSelecionado.cbUF.setSelectedIndex(14);
                break;
            case "PR":
                carregaSelecionado.cbUF.setSelectedIndex(15);
                break;
            case "PE":
                carregaSelecionado.cbUF.setSelectedIndex(16);
                break;
            case "PI":
                carregaSelecionado.cbUF.setSelectedIndex(17);
                break;
            case "RJ":
                carregaSelecionado.cbUF.setSelectedIndex(18);
                break;
            case "RN":
                carregaSelecionado.cbUF.setSelectedIndex(19);
                break;
            case "RS":
                carregaSelecionado.cbUF.setSelectedIndex(20);
                break;
            case "RO":
                carregaSelecionado.cbUF.setSelectedIndex(21);
                break;
            case "RR":
                carregaSelecionado.cbUF.setSelectedIndex(22);
                break;
            case "SC":
                carregaSelecionado.cbUF.setSelectedIndex(23);
                break;
            case "SP":
                carregaSelecionado.cbUF.setSelectedIndex(24);
                break;
            case "SE":
                carregaSelecionado.cbUF.setSelectedIndex(25);
                break;
            case "TO":
                carregaSelecionado.cbUF.setSelectedIndex(26);
                break;
            default:
                carregaSelecionado.cbUF.setSelectedIndex(-1);
                break;
        }

        this.dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbLista = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        tbLista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbLista);
        if (tbLista.getColumnModel().getColumnCount() > 0) {
            tbLista.getColumnModel().getColumn(0).setResizable(false);
            tbLista.getColumnModel().getColumn(1).setResizable(false);
        }

        jButton1.setText("Selecionar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        pesquisar_usuario();
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        carregaDadosTabelaPesquisarContato();
    }//GEN-LAST:event_formWindowOpened

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        selecionaDadoFiltrado();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frm_buscar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frm_buscar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frm_buscar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frm_buscar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frm_buscar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbLista;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
